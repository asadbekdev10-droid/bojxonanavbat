/**
 * ONE ID (id.egov.uz) — OAuth 2.0 integratsiya moduli
 * Rasmiy murojaat: https://id.egov.uz
 * Texnik savolar: 55-501-36-06 (ichki 1118)
 */

const axios = require('axios');

const ONEID_CONFIG = {
  baseURL:      'https://sso.egov.uz',
  clientId:     process.env.ONEID_CLIENT_ID,      // Raqamli texnologiyalar vazirligidan olinadi
  clientSecret: process.env.ONEID_CLIENT_SECRET,
  redirectUri:  process.env.ONEID_REDIRECT_URI,   // masalan: https://bojxona-navbat.uz/auth/callback
  scope:        'openid profile',
};

/**
 * 1-QADAM: Foydalanuvchini ONE ID login sahifasiga yo'naltirish
 */
function getAuthorizationUrl(state) {
  const params = new URLSearchParams({
    response_type: 'code',
    client_id:     ONEID_CONFIG.clientId,
    redirect_uri:  ONEID_CONFIG.redirectUri,
    scope:         ONEID_CONFIG.scope,
    state,           // CSRF himoyasi uchun
  });
  return `${ONEID_CONFIG.baseURL}/oauth2/authorization?${params}`;
}

/**
 * 2-QADAM: Authorization code → access_token almashtirish
 */
async function exchangeCodeForToken(code) {
  const response = await axios.post(
    `${ONEID_CONFIG.baseURL}/oauth2/token`,
    new URLSearchParams({
      grant_type:    'authorization_code',
      code,
      redirect_uri:  ONEID_CONFIG.redirectUri,
      client_id:     ONEID_CONFIG.clientId,
      client_secret: ONEID_CONFIG.clientSecret,
    }),
    { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
  );
  return response.data; // { access_token, refresh_token, expires_in, token_type }
}

/**
 * 3-QADAM: access_token orqali foydalanuvchi ma'lumotlarini olish
 * Qaytariladi: { sub, jsh_shir, first_name, last_name, middle_name, phone_number, ... }
 */
async function getUserInfo(accessToken) {
  const response = await axios.get(
    `${ONEID_CONFIG.baseURL}/oauth2/userinfo`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  const u = response.data;
  // O'zimizning formatga moslashtirish
  return {
    oneIdSub:     u.sub,
    jshshir:      u.pin,           // 14 raqamli JSHSHIR
    firstName:    u.first_name,
    lastName:     u.last_name,
    middleName:   u.middle_name,
    phoneNumber:  u.mob_phone_no,  // +998XXXXXXXXX
    birthDate:    u.birth_date,
    passportSeries: u.doc_series,
    passportNumber: u.doc_number,
    citizenship:  u.citizenship,
  };
}

/**
 * Express.js Route handlerlari
 */
const crypto = require('crypto');

// GET /auth/oneid — foydalanuvchini ONE ID ga yo'naltirish
async function redirectToOneId(req, res) {
  const state = crypto.randomBytes(16).toString('hex');
  req.session.oauthState = state;
  res.redirect(getAuthorizationUrl(state));
}

// GET /auth/callback — ONE ID qaytib kelganda
async function handleCallback(req, res) {
  const { code, state, error } = req.query;

  if (error) {
    return res.status(400).json({ message: 'ONE ID kirish rad etildi', error });
  }
  if (state !== req.session.oauthState) {
    return res.status(400).json({ message: 'CSRF tekshiruvi muvaffaqiyatsiz' });
  }

  try {
    // Token olish
    const tokenData = await exchangeCodeForToken(code);

    // Foydalanuvchi ma'lumotlarini olish
    const userInfo = await getUserInfo(tokenData.access_token);

    // Foydalanuvchini DB da topish yoki yaratish
    const { User } = require('../models');
    let user = await User.findOne({ where: { jshshir: userInfo.jshshir } });

    if (!user) {
      user = await User.create({
        jshshir:      userInfo.jshshir,
        firstName:    userInfo.firstName,
        lastName:     userInfo.lastName,
        phoneNumber:  userInfo.phoneNumber,
        citizenship:  userInfo.citizenship || 'UZ',
        oneidSub:     userInfo.oneIdSub,
        status:       'active',
      });
    }

    // JWT token yaratish (o'zimizning)
    const jwt = require('jsonwebtoken');
    const token = jwt.sign(
      { userId: user.id, jshshir: user.jshshir },
      process.env.JWT_SECRET,
      { expiresIn: '15m' }
    );
    const refreshToken = jwt.sign(
      { userId: user.id },
      process.env.JWT_REFRESH_SECRET,
      { expiresIn: '30d' }
    );

    res.json({ token, refreshToken, user: { id: user.id, firstName: user.firstName, lastName: user.lastName } });
  } catch (err) {
    console.error('ONE ID callback xatosi:', err.message);
    res.status(500).json({ message: 'Autentifikatsiya xatosi' });
  }
}

module.exports = { redirectToOneId, handleCallback, getAuthorizationUrl };
