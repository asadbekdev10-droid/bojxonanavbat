/**
 * IIP2 — Idoralararo Integratsiya Platformasi
 * Transport, jarima, soliq, sug'urta tekshiruv moduli
 * Rasmiy: egov.uz orqali shartnoma asosida API kalitlari beriladi
 */

const axios = require('axios');

// IIP2 ga ulanish konfiguratsiyasi
const IIP2 = axios.create({
  baseURL: process.env.IIP2_BASE_URL || 'https://api.egov.uz/iip2/v1',
  timeout: 15000,
  headers: {
    'X-API-Key':      process.env.IIP2_API_KEY,
    'X-Organization': process.env.IIP2_ORG_CODE,   // Bojxona qo'mitasi kodi
    'Content-Type':   'application/json',
  },
});

// ─── 1. Transport vositasi ro'yxatdan o'tganligi ────────────────────────────
async function checkVehicleRegistration(plateNumber) {
  try {
    const { data } = await IIP2.get('/yhq/vehicle', { params: { plate: plateNumber } });
    return {
      check: 'vehicle_registered',
      passed: data.isRegistered === true,
      details: {
        ownerName:   data.ownerName,
        vehicleType: data.vehicleType,
        expireDate:  data.techPassportExpiry,
      },
    };
  } catch (e) {
    return { check: 'vehicle_registered', passed: false, error: e.message };
  }
}

// ─── 2. Haydovchilik guvohnomasi ────────────────────────────────────────────
async function checkDriverLicense(jshshir) {
  try {
    const { data } = await IIP2.get('/yhq/license', { params: { pin: jshshir } });
    return {
      check: 'license_valid',
      passed: data.isValid && !data.isSuspended,
      details: {
        category:   data.categories,
        expireDate: data.expireDate,
        suspended:  data.isSuspended,
      },
    };
  } catch (e) {
    return { check: 'license_valid', passed: false, error: e.message };
  }
}

// ─── 3. YHQ jarimalar ───────────────────────────────────────────────────────
async function checkTrafficFines(jshshir, plateNumber) {
  try {
    const { data } = await IIP2.get('/yhq/fines', {
      params: { pin: jshshir, plate: plateNumber },
    });
    const unpaid = data.fines?.filter(f => f.status === 'unpaid') || [];
    return {
      check: 'no_traffic_fines',
      passed: unpaid.length === 0,
      details: {
        totalUnpaid: unpaid.reduce((s, f) => s + f.amount, 0),
        finesCount:  unpaid.length,
        fines:       unpaid.map(f => ({ id: f.id, amount: f.amount, date: f.date, description: f.description })),
      },
    };
  } catch (e) {
    return { check: 'no_traffic_fines', passed: false, error: e.message };
  }
}

// ─── 4. Xalqaro tashish ruxsatnomasi ────────────────────────────────────────
async function checkInternationalPermit(plateNumber) {
  try {
    const { data } = await IIP2.get('/customs/intl-permit', { params: { plate: plateNumber } });
    return {
      check: 'intl_permit_valid',
      passed: data.hasPermit && new Date(data.expireDate) > new Date(),
      details: {
        permitNumber: data.permitNumber,
        expireDate:   data.expireDate,
        routes:       data.allowedRoutes,
      },
    };
  } catch (e) {
    return { check: 'intl_permit_valid', passed: false, error: e.message };
  }
}

// ─── 5. Pullik yo'llar qarzdorligi ──────────────────────────────────────────
async function checkTollDebt(plateNumber) {
  try {
    const { data } = await IIP2.get('/roads/toll-debt', { params: { plate: plateNumber } });
    return {
      check: 'no_toll_debt',
      passed: data.totalDebt === 0,
      details: {
        totalDebt: data.totalDebt,
        currency:  'UZS',
        segments:  data.debtSegments,
      },
    };
  } catch (e) {
    return { check: 'no_toll_debt', passed: false, error: e.message };
  }
}

// ─── 6. Sug'urta ────────────────────────────────────────────────────────────
async function checkInsurance(jshshir, plateNumber) {
  try {
    const { data } = await IIP2.get('/insurance/check', {
      params: { pin: jshshir, plate: plateNumber },
    });
    return {
      check: 'insurance_valid',
      passed: data.driverInsured && data.vehicleInsured,
      details: {
        driverPolicy:  { valid: data.driverInsured, expiry: data.driverPolicyExpiry },
        vehiclePolicy: { valid: data.vehicleInsured, expiry: data.vehiclePolicyExpiry },
      },
    };
  } catch (e) {
    return { check: 'insurance_valid', passed: false, error: e.message };
  }
}

// ─── 7. Soliq qarzdorligi ───────────────────────────────────────────────────
async function checkTaxDebt(jshshir) {
  try {
    const { data } = await IIP2.get('/tax/debt', { params: { pin: jshshir } });
    return {
      check: 'no_tax_debt',
      passed: data.totalDebt === 0,
      details: {
        totalDebt: data.totalDebt,
        currency:  'UZS',
        types:     data.debtTypes,
      },
    };
  } catch (e) {
    return { check: 'no_tax_debt', passed: false, error: e.message };
  }
}

// ─── ASOSIY: barcha 7 ta tekshiruv parallel ─────────────────────────────────
async function runAllChecks({ jshshir, plateNumber }) {
  const startTime = Date.now();

  // Hammasi bir vaqtda parallel — tezroq
  const results = await Promise.allSettled([
    checkVehicleRegistration(plateNumber),
    checkDriverLicense(jshshir),
    checkTrafficFines(jshshir, plateNumber),
    checkInternationalPermit(plateNumber),
    checkTollDebt(plateNumber),
    checkInsurance(jshshir, plateNumber),
    checkTaxDebt(jshshir),
  ]);

  const checks = results.map(r =>
    r.status === 'fulfilled' ? r.value : { passed: false, error: r.reason?.message }
  );

  const allPassed = checks.every(c => c.passed);

  return {
    overallResult: allPassed ? 'passed' : 'failed',
    durationMs:    Date.now() - startTime,
    checks: {
      vehicleRegistered: checks[0],
      licenseValid:      checks[1],
      noTrafficFines:    checks[2],
      intlPermitValid:   checks[3],
      noTollDebt:        checks[4],
      insuranceValid:    checks[5],
      noTaxDebt:         checks[6],
    },
  };
}

module.exports = { runAllChecks, checkVehicleRegistration, checkDriverLicense,
  checkTrafficFines, checkInternationalPermit, checkTollDebt, checkInsurance, checkTaxDebt };
