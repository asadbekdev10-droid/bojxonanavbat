/**
 * my.gov.uz — IBR (Ruxsatnoma blankasi berish) xizmati integratsiyasi
 * Xizmat kodi: bojxona xizmati kodi (shartnoma asosida beriladi)
 */

const axios = require('axios');

const MYGOV = axios.create({
  baseURL: process.env.MYGOV_API_URL || 'https://api.my.gov.uz/v1',
  timeout: 20000,
  headers: {
    'Authorization': `Bearer ${process.env.MYGOV_SERVICE_TOKEN}`,
    'X-Service-Code': process.env.MYGOV_IBR_SERVICE_CODE,
    'Content-Type':   'application/json',
  },
});

/**
 * IBR 2-bosqich: Davlat xizmatini buyurtma qilish
 * Foydalanuvchi my.gov.uz ga ONE ID orqali kirgan va xizmatni tanlagan
 */
async function orderIbrService({ oneIdToken, bookingId, plateNumber, transportType }) {
  const { data } = await MYGOV.post('/services/customs/ibr/order', {
    userToken:     oneIdToken,
    bookingId,
    vehiclePlate:  plateNumber,
    transportType,
    requestedDate: new Date().toISOString(),
  });
  return {
    serviceOrderId: data.orderId,
    orderStatus:    data.status,        // 'pending' | 'confirmed' | 'rejected'
    trackingUrl:    data.trackingUrl,   // my.gov.uz da kuzatish havolasi
  };
}

/**
 * IBR buyurtma holatini tekshirish
 */
async function checkIbrOrderStatus(serviceOrderId) {
  const { data } = await MYGOV.get(`/services/orders/${serviceOrderId}/status`);
  return {
    orderId:    data.orderId,
    status:     data.status,
    updatedAt:  data.updatedAt,
    comment:    data.comment,
  };
}

/**
 * IBR 4-bosqich: Davlat boji to'lovini tekshirish
 * (Foydalanuvchi my.gov.uz orqali to'lagan)
 */
async function checkIbrPaymentStatus(serviceOrderId) {
  const { data } = await MYGOV.get(`/services/orders/${serviceOrderId}/payment`);
  return {
    isPaid:     data.isPaid,
    amount:     data.amount,
    currency:   data.currency || 'UZS',
    paidAt:     data.paidAt,
    receiptUrl: data.receiptUrl,
  };
}

/**
 * WEBHOOK: my.gov.uz AENT ga xabar yuboradi (holat o'zgarganda)
 * Express.js POST /webhooks/mygov endpointida ishlaydi
 */
async function handleMyGovWebhook(req, res) {
  const signature = req.headers['x-mygov-signature'];

  // Webhook imzosini tekshirish
  const crypto = require('crypto');
  const expectedSig = crypto
    .createHmac('sha256', process.env.MYGOV_WEBHOOK_SECRET)
    .update(JSON.stringify(req.body))
    .digest('hex');

  if (signature !== expectedSig) {
    return res.status(401).json({ message: "Imzo noto'g'ri" });
  }

  const { event, orderId, status, data } = req.body;

  const { Booking } = require('../models');
  const booking = await Booking.findOne({ where: { myGovOrderId: orderId } });

  if (!booking) return res.status(404).json({ message: 'Bron topilmadi' });

  switch (event) {
    case 'order.confirmed':
      await booking.update({ bookingStatus: 'confirmed' });
      break;
    case 'payment.completed':
      await booking.update({ paymentStatus: 'paid', paidAt: data.paidAt });
      // SMS yuborish
      const smsService = require('./sms');
      await smsService.send({
        phone:   booking.userPhone,
        message: `IBR to'lovi qabul qilindi. Chipta: ${booking.ticketNumber}. Vaqt: ${booking.slotTime}.`,
      });
      break;
    case 'order.rejected':
      await booking.update({ bookingStatus: 'rejected', cancelReason: data.reason });
      break;
  }

  res.json({ received: true });
}

/**
 * my.gov.uz SSO (Single Sign-On) redirect — foydalanuvchini
 * my.gov.uz dagi IBR xizmatiga to'g'ridan-to'g'ri yo'naltirish
 */
function getMyGovIbrUrl(bookingId) {
  const params = new URLSearchParams({
    service:    process.env.MYGOV_IBR_SERVICE_CODE,
    booking_id: bookingId,
    callback:   `${process.env.APP_BASE_URL}/auth/mygov-callback`,
  });
  return `https://my.gov.uz/services/customs/ibr?${params}`;
}

module.exports = { orderIbrService, checkIbrOrderStatus, checkIbrPaymentStatus,
  handleMyGovWebhook, getMyGovIbrUrl };
