/**
 * AENT — Integratsiya yo'naltiruvchi
 * Barcha tashqi tizimlarni boshqaradi: ONE ID, IIP2, my.gov.uz
 */

const express = require('express');
const router  = express.Router();

const oneId  = require('./oneid');
const iip2   = require('./iip2');
const myGov  = require('./mygov');

// ─── ONE ID autentifikatsiya ─────────────────────────────────────────────────
router.get('/auth/oneid',    oneId.redirectToOneId);     // Foydalanuvchini ONE ID ga yo'naltirish
router.get('/auth/callback', oneId.handleCallback);      // ONE ID qaytib kelganda

// ─── IIP2 tekshiruv ──────────────────────────────────────────────────────────
router.post('/verify/booking/:id', async (req, res) => {
  const { Booking, User, VerificationCheck } = require('../models');
  const booking = await Booking.findByPk(req.params.id, { include: [User] });
  if (!booking) return res.status(404).json({ message: 'Bron topilmadi' });

  const results = await iip2.runAllChecks({
    jshshir:     booking.User.jshshir,
    plateNumber: booking.plateNumber,
  });

  // Natijani DBga saqlash
  await VerificationCheck.create({
    bookingId:         booking.id,
    vehicleRegistered: results.checks.vehicleRegistered.passed,
    licenseValid:      results.checks.licenseValid.passed,
    noTrafficFines:    results.checks.noTrafficFines.passed,
    intlPermitValid:   results.checks.intlPermitValid.passed,
    noTollDebt:        results.checks.noTollDebt.passed,
    insuranceValid:    results.checks.insuranceValid.passed,
    noTaxDebt:         results.checks.noTaxDebt.passed,
    overallResult:     results.overallResult,
    rawResponses:      results.checks,
  });

  // Tekshiruv o'tsa — bronni tasdiqlash
  if (results.overallResult === 'passed') {
    await booking.update({ bookingStatus: 'verified' });
  }

  res.json(results);
});

// ─── my.gov.uz IBR ───────────────────────────────────────────────────────────
router.post('/mygov/ibr/order', async (req, res) => {
  const { bookingId, oneIdToken } = req.body;
  const { Booking } = require('../models');
  const booking = await Booking.findByPk(bookingId);
  if (!booking) return res.status(404).json({ message: 'Bron topilmadi' });

  const order = await myGov.orderIbrService({
    oneIdToken,
    bookingId,
    plateNumber:   booking.plateNumber,
    transportType: booking.transportType,
  });

  await booking.update({ myGovOrderId: order.serviceOrderId });
  res.json(order);
});

router.get('/mygov/ibr/:orderId/status', async (req, res) => {
  const status = await myGov.checkIbrOrderStatus(req.params.orderId);
  res.json(status);
});

// my.gov.uz webhook — xabarlar qabul qilish
router.post('/webhooks/mygov', myGov.handleMyGovWebhook);

// ─── Holat tekshiruv ─────────────────────────────────────────────────────────
router.get('/integrations/health', async (req, res) => {
  const checks = await Promise.allSettled([
    axios.get(`${process.env.ONEID_BASE_URL}/.well-known/openid-configuration`, { timeout: 3000 }),
    axios.get(`${process.env.IIP2_BASE_URL}/health`, { timeout: 3000 }),
    axios.get(`${process.env.MYGOV_API_URL}/health`, { timeout: 3000 }),
  ]);

  res.json({
    timestamp: new Date().toISOString(),
    services: {
      oneid:  checks[0].status === 'fulfilled' ? 'ok' : 'down',
      iip2:   checks[1].status === 'fulfilled' ? 'ok' : 'down',
      mygov:  checks[2].status === 'fulfilled' ? 'ok' : 'down',
    },
  });
});

module.exports = router;
